package com.ust.springsecurity.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Securitycontroller
{
    @GetMapping("/security")
    public String security(){
        return "hello admin";
    }

    @GetMapping("/user")
    public String user(){
        return "welcome user";
    }
}

